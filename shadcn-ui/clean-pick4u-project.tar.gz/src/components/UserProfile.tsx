import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { User } from '@/types';
import { israeliCities } from '@/data/cities';

interface UserProfileProps {
  user: User;
  onUpdate: (user: User) => void;
}

export default function UserProfile({ user, onUpdate }: UserProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(user);

  const handleSave = () => {
    onUpdate(formData);
    setIsEditing(false);
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 rounded-3xl shadow-xl">
      <CardHeader>
        <CardTitle className="text-2xl bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          הפרופיל שלי
        </CardTitle>
        <CardDescription>
          עדכן את הפרטים האישיים שלך
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {isEditing ? (
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">שם מלא</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="rounded-xl"
              />
            </div>
            
            <div>
              <Label htmlFor="phone">טלפון</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="rounded-xl"
              />
            </div>
            
            <div>
              <Label htmlFor="city">עיר</Label>
              <Select value={formData.city} onValueChange={(value) => setFormData({ ...formData, city: value })}>
                <SelectTrigger className="rounded-xl">
                  <SelectValue placeholder="בחר עיר" />
                </SelectTrigger>
                <SelectContent>
                  {israeliCities.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex gap-4">
              <Button onClick={handleSave} className="flex-1 rounded-xl">
                שמור שינויים
              </Button>
              <Button variant="outline" onClick={() => setIsEditing(false)} className="flex-1 rounded-xl">
                ביטול
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="font-medium">שם:</span>
              <span>{user.name}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-medium">טלפון:</span>
              <span>{user.phone}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-medium">עיר:</span>
              <span>{user.city}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-medium">קהילה:</span>
              <span>{user.community || 'לא נבחרה'}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-medium">דירוג:</span>
              <span>{user.rating.toFixed(1)} ⭐</span>
            </div>
            
            <Button onClick={() => setIsEditing(true)} className="w-full rounded-xl">
              עריכת פרופיל
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}