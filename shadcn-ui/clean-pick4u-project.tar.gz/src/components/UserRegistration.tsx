import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { User } from '@/types';
import { israeliCities } from '@/data/cities';

interface UserRegistrationProps {
  onRegister: (user: User) => void;
}

export default function UserRegistration({ onRegister }: UserRegistrationProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    password: '',
    city: '',
    community: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newUser: User = {
      id: Date.now().toString(),
      name: formData.name,
      phone: formData.phone,
      city: formData.city,
      community: formData.community,
      avatar: '👤',
      rating: 5.0,
      completedDeliveries: 0,
      isVerified: false,
      createdAt: new Date()
    };
    
    onRegister(newUser);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">שם מלא</Label>
        <Input
          id="name"
          placeholder="הכנס שם מלא"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          required
          className="rounded-xl"
        />
      </div>
      
      <div>
        <Label htmlFor="phone">מספר טלפון</Label>
        <Input
          id="phone"
          type="tel"
          placeholder="050-1234567"
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          required
          className="rounded-xl"
        />
      </div>
      
      <div>
        <Label htmlFor="password">סיסמה</Label>
        <Input
          id="password"
          type="password"
          placeholder="בחר סיסמה"
          value={formData.password}
          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
          required
          className="rounded-xl"
        />
      </div>
      
      <div>
        <Label htmlFor="city">עיר מגורים</Label>
        <Select value={formData.city} onValueChange={(value) => setFormData({ ...formData, city: value })}>
          <SelectTrigger className="rounded-xl">
            <SelectValue placeholder="בחר עיר" />
          </SelectTrigger>
          <SelectContent>
            {israeliCities.slice(0, 20).map((city) => (
              <SelectItem key={city} value={city}>
                {city}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label htmlFor="community">קהילה (אופציונלי)</Label>
        <Input
          id="community"
          placeholder="שם הקהילה או השכונה"
          value={formData.community}
          onChange={(e) => setFormData({ ...formData, community: e.target.value })}
          className="rounded-xl"
        />
      </div>
      
      <Button type="submit" className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600">
        הצטרף לקהילה
      </Button>
    </form>
  );
}