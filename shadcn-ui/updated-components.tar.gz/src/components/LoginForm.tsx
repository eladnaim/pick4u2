import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { User } from '@/types';

interface LoginFormProps {
  onLogin: (user: User) => void;
  onSwitchToRegister: () => void;
}

export default function LoginForm({ onLogin, onSwitchToRegister }: LoginFormProps) {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Mock login - in real app, this would authenticate with backend
    const mockUser: User = {
      id: '1',
      name: 'משתמש דמו',
      phone,
      city: 'תל אביב',
      community: 'קהילת תל אביב',
      avatar: '👤',
      rating: 4.8,
      completedDeliveries: 12,
      isVerified: true,
      createdAt: new Date()
    };
    
    onLogin(mockUser);
  };

  return (
    <Card className="backdrop-blur-xl bg-white/90 border-0 shadow-2xl rounded-3xl">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          התחברות לחשבון
        </CardTitle>
        <CardDescription className="text-gray-600">
          הכנס את הפרטים שלך להתחברות
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="phone">מספר טלפון</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="050-1234567"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
              className="rounded-xl"
            />
          </div>
          
          <div>
            <Label htmlFor="password">סיסמה</Label>
            <Input
              id="password"
              type="password"
              placeholder="הכנס סיסמה"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="rounded-xl"
            />
          </div>
          
          <Button type="submit" className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600">
            התחבר
          </Button>
          
          <Button
            type="button"
            variant="ghost"
            onClick={onSwitchToRegister}
            className="w-full text-blue-600 hover:text-blue-700"
          >
            אין לך חשבון? הרשם כאן
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}