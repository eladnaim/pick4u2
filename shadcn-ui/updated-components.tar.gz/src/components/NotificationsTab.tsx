import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Bell, Package, MessageCircle, Star, CheckCircle } from 'lucide-react';
import { User } from '@/types';

interface NotificationsTabProps {
  user: User;
}

// Mock notifications data
const mockNotifications = [
  {
    id: '1',
    type: 'pickup_request',
    title: 'בקשת איסוף חדשה',
    message: 'שרה כהן ביקשה איסוף חבילה מדואר ישראל',
    time: 'לפני 15 דקות',
    isRead: false,
    icon: Package
  },
  {
    id: '2',
    type: 'message',
    title: 'הודעה חדשה',
    message: 'דוד לוי שלח לך הודעה בצ\'אט',
    time: 'לפני 30 דקות',
    isRead: false,
    icon: MessageCircle
  },
  {
    id: '3',
    type: 'rating',
    title: 'דירוג חדש',
    message: 'קיבלת דירוג 5 כוכבים על המשלוח האחרון!',
    time: 'לפני שעה',
    isRead: true,
    icon: Star
  },
  {
    id: '4',
    type: 'delivery_completed',
    title: 'משלוח הושלם',
    message: 'המשלוח לרחוב הרצל 15 הושלם בהצלחה',
    time: 'לפני 2 שעות',
    isRead: true,
    icon: CheckCircle
  }
];

export default function NotificationsTab({ user }: NotificationsTabProps) {
  const unreadCount = mockNotifications.filter(n => !n.isRead).length;

  const getNotificationColor = (type: string, isRead: boolean) => {
    if (isRead) return 'bg-gray-50 border-gray-200';
    
    switch (type) {
      case 'pickup_request': return 'bg-blue-50 border-blue-200';
      case 'message': return 'bg-green-50 border-green-200';
      case 'rating': return 'bg-yellow-50 border-yellow-200';
      case 'delivery_completed': return 'bg-purple-50 border-purple-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  const getIconColor = (type: string) => {
    switch (type) {
      case 'pickup_request': return 'text-blue-600 bg-blue-100';
      case 'message': return 'text-green-600 bg-green-100';
      case 'rating': return 'text-yellow-600 bg-yellow-100';
      case 'delivery_completed': return 'text-purple-600 bg-purple-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="bg-white/80 backdrop-blur-sm border-0 rounded-3xl shadow-xl mb-8">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent font-bold flex items-center justify-center gap-3">
            <Bell className="w-8 h-8 text-orange-600" />
            התרעות
          </CardTitle>
          <CardDescription className="text-gray-600 text-lg">
            {unreadCount > 0 ? `יש לך ${unreadCount} התרעות חדשות` : 'אין התרעות חדשות'}
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="space-y-4">
        {mockNotifications.map((notification) => {
          const IconComponent = notification.icon;
          return (
            <Card 
              key={notification.id} 
              className={`hover:shadow-lg transition-all duration-300 border-2 rounded-2xl ${getNotificationColor(notification.type, notification.isRead)}`}
            >
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 ${getIconColor(notification.type)}`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-bold text-lg text-gray-800 mb-1">
                          {notification.title}
                          {!notification.isRead && (
                            <Badge className="mr-2 bg-red-100 text-red-800 text-xs">
                              חדש
                            </Badge>
                          )}
                        </h3>
                        <p className="text-gray-600 leading-relaxed">
                          {notification.message}
                        </p>
                      </div>
                      <span className="text-sm text-gray-500 whitespace-nowrap">
                        {notification.time}
                      </span>
                    </div>
                    
                    {!notification.isRead && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="mt-3 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-xl"
                      >
                        סמן כנקרא
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {mockNotifications.length === 0 && (
        <Card className="bg-white/80 backdrop-blur-sm border-0 rounded-3xl shadow-xl">
          <CardContent className="text-center py-16">
            <Bell className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-700 mb-2">אין התרעות</h3>
            <p className="text-gray-600">התרעות חדשות יופיעו כאן</p>
          </CardContent>
        </Card>
      )}

      {unreadCount > 0 && (
        <div className="mt-8 text-center">
          <Button 
            variant="outline" 
            className="rounded-2xl border-2 border-blue-200 hover:border-blue-300 bg-white/80 hover:bg-white shadow-lg hover:shadow-xl transition-all duration-300"
          >
            סמן הכל כנקרא ({unreadCount})
          </Button>
        </div>
      )}
    </div>
  );
}